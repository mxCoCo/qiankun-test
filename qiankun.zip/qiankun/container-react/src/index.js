import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

import {registerMicroApps,start} from 'qiankun'

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

registerMicroApps([
  {
      name: 'react-app', // app name registered
      entry: '//localhost:3001',// 默认加载html资源，解析里面的js动态执行（子应用必须支持跨越）
      container: '#react',
      activeRule: '/react'
  },
  {
      name: 'react-eject-app', // app name registered
      entry: '//localhost:3004',// 默认加载html资源，解析里面的js动态执行（子应用必须支持跨越）
      container: '#react-eject',
      activeRule: '/react-eject'
  },
  {
      name: 'vue-app',
      entry: '//localhost:3002',
      container: '#vue',
      activeRule: '/vue'
  },
  {
      name: 'vue3-app',
      entry: '//localhost:3003',
      container: '#vue3',
      activeRule: '/vue3'
  },
]);

start({
  // prefetch:false
});


// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
