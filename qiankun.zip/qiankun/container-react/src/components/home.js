import React, { Component } from 'react'

export default class home extends Component {
    render() {
        return (
            <div>
                react-application home Page
            </div>
        )
    }
}
