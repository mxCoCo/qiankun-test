import React ,{Component} from 'react'

export default class about extends Component {
    render() {
        return (
            <div>
                react-application about Page
            </div>
        )
    }
}