import {BrowserRouter, Switch ,Route,Link} from 'react-router-dom'
import Home from './components/home'
import About from './components/about'

function App(props) {
  return <BrowserRouter>
  <div>
    <Link to="/">home</Link><br/>
    <Link to="/about">about</Link><br/>
    <Link to="/vue">vue</Link><br/>
    <Link to="/vue3">vue3</Link><br/>
    <Link to="/react">react</Link><br/>
    <Link to="/react-eject">react-eject</Link><br/>
  </div>
  <div id="vue"></div>
  <div id="vue3"></div>
  <div id="react"></div>
  <div id="react-eject"></div>
  <Switch >
    <Route exact path="/" component={Home}></Route>
    <Route exact path="/about" component={About}></Route>
  </Switch >
  {props.children}
</BrowserRouter>
}

export default App;
