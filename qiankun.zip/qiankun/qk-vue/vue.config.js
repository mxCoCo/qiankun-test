module.exports = {
    devServer: {
        port: 3002,
        headers: {
            'Access-Control-Allow-Origin':"*"
        }
    },
    configureWebpack: {
        output:{
            library: "vue-app",
            libraryTarget: 'umd'
        }
    }
}