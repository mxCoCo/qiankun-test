<template>
  <div id="app">
    <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link>
    <!-- <div id="nav" v-if="isQk">
      <router-link to="/vue/">Home</router-link> |
      <router-link to="/vue/about">About</router-link>
    </div>
    <div id="nav" v-if="!isQk">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </div> -->
    <router-view/>
  </div>
</template>
<script>
export default {
  name: 'App',
  data(){
    return {
      isQk: false
    }
  },
  mounted(){
    if(window.__POWERED_BY_QIANKUN__){
      this.isQk = true
    }
  }
}
</script>
<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
