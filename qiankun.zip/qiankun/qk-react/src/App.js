import {BrowserRouter, Switch ,Route,Link} from 'react-router-dom'
import Home from './components/home'
import About from './components/about'

function App() {
  return <BrowserRouter basename={window.__POWERED_BY_QIANKUN__ ? '/react' : '/'}>
    <div>
      <Link to="/">home</Link><br/>
      <Link to="/about">about</Link>
    </div>
  <Switch >
    <Route exact path="/" component={Home}></Route>
    <Route exact path="/about" component={About}></Route>
  </Switch >
</BrowserRouter>
}

export default App;
