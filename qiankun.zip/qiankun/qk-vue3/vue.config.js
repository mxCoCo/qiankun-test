module.exports = {
    devServer: {
        port: 3003,
        headers: {
            'Access-Control-Allow-Origin':"*"
        }
    },
    configureWebpack: {
        output:{
            library: "vue3-app",
            libraryTarget: 'umd'
        }
    },
    chainWebpack: (config) => {
        config.module.rule('fonts').use('url-loader').loader('url-loader').options({}).end();
        config.module.rule('images').use('url-loader').loader('url-loader').options({}).end();
    },
}