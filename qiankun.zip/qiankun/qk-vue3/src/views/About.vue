<template>
  <div class="about">
    <h1>This is an about page {{msg}}</h1>
  </div>
</template>
<script setup>
import { ref } from "vue";
const msg = ref('hello')
</script>
