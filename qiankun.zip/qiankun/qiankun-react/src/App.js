// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;
import {BrowserRouter, Switch ,Route,Link} from 'react-router-dom'
import Home from './components/home'
import About from './components/about'

function App() {
  return <BrowserRouter basename={window.__POWERED_BY_QIANKUN__ ? '/react-eject' : '/'}>
    <div>
      <Link to="/">home</Link><br/>
      <Link to="/about">about</Link>
    </div>
  <Switch >
    <Route exact path="/" component={Home}></Route>
    <Route exact path="/about" component={About}></Route>
  </Switch >
</BrowserRouter>
}

export default App;
